# C++ 设计模式

归档 23 种 [C++ 设计模式](https://waleon.blog.csdn.net/article/details/66974516 "C++ 设计模式")，所有示例均基于 VS2015。

# 更多精彩

- 个人博客：[一去、二三里](https://waleon.blog.csdn.net/ "一去、二三里")
- 微信号：iwaleon
- 微信公众号：高效程序员

![微信公众号](https://raw.githubusercontent.com/Waleon/DesignPatterns/master/assets/qrcode.jpg)

更多干货，请扫码关注微信公众号，不要太惊喜哦~
